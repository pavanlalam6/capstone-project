﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace malshetwi_CapstoneProject_SDA.LMS.Data
{
    public enum MedicineCategory
    {
        MumAndBaby,
        BeautyCare,
        PersonalCare,
        MedicineAndTreatment,
        Vitamins
    }
}
